clear;
%close all;

folder = 'ryans_south_boulder_test';

addpath(folder);


%% INPUT CALIBRATION DATA

calibration.node_lat = ddmmss2decimal(39, 58, 49.72); % input GPS location for node
calibration.node_lon = -ddmmss2decimal(105, 13, 51.26); % input GPS location for node

calibration.start_lat = ddmmss2decimal(39, 58, 49.10); % input starting GPS location for beacon
calibration.start_lon = -ddmmss2decimal(105, 13, 51.53); % input starting GPS location for beacon

calibration.stop_lat = ddmmss2decimal(39, 58, 49.10); % input ending GPS location for beacon
calibration.stop_lon = -ddmmss2decimal(105, 13, 51.53); % input ending GPS location for beacon

[calibration.start_x, calibration.start_y, ~, theta] = latlon_to_xy(calibration.start_lat, calibration.start_lon, calibration.node_lat, calibration.node_lon);
[calibration.stop_x, calibration.stop_y] = latlon_to_xy(calibration.stop_lat, calibration.stop_lon, calibration.node_lat, calibration.node_lon);

%% Begin Reading Data from Pi

file_names = dir(folder);
file_names = file_names(3:end);

count = 0;
for i = 1:length(file_names)
    data = readstruct(file_names(i).name);
    
    % loop through the number of RID packets per data frame
    for j = 1:length(data)        
        % extract latitude and longitude as "strings" (double quotations!)
        lat_s = data(j).rid.opendroneid_message_location.OpenDroneID_loc_lat; % deg
        lon_s = data(j).rid.opendroneid_message_location.OpenDroneID_loc_lon; % deg

        %lat_s = data(j).rid.opendroneid_message_system.OpenDroneID_system_lat; % deg
        %lon_s = data(j).rid.opendroneid_message_system.OpenDroneID_system_lon; % deg

        if lat_s == '0'
            % ...then GPS has not locked
            fprintf('%s\n', 'GPS not locked, skipping RID packet...');
            continue
        end

        count = count + 1; % increment the count variable for indexing

        % convert from string to char
        lat_s = char(lat_s);
        lon_s = char(lon_s);

        % add a decimal point, and then convert to double
        lat_all(count) = str2double([lat_s(1:2), '.', lat_s(3:end)]);
        lon_all(count) = str2double([lon_s(1:4), '.', lon_s(5:end)]);

        strength(count) = str2double(data(j).signal_dBm); % dBm (watts)
    end
end


%% Get Node Location (from RID Broadcast)

lat_n = data(1).rid.opendroneid_message_system.OpenDroneID_system_lat; % deg
lon_n = data(1).rid.opendroneid_message_system.OpenDroneID_system_lon; % deg

% convert from string to char
lat_n = char(lat_n);
lon_n = char(lon_n);

% add a decimal point, and then convert to double
lat_n = str2double([lat_n(1:2), '.', lat_n(3:end)]);
lon_n = str2double([lon_n(1:4), '.', lon_n(5:end)]);

%% Calibrate Measurements

% calibrate the node
% WITH THIS, LAT_N and LON_N ARE BEING OVERWRITTEN!
% lat_offset = lat_n - reflat;
% lon_offset = lon_n - reflon;
% lat_n = lat_n - lat_offset;
% lon_n = lon_n - lon_offset;
% 
% % calibrate the drone beacon
% lat_offset = lat_all(1) - lat_rid_reference;
% lon_offset = lon_all(1) - lon_rid_reference;
% lat_all = lat_all - lat_offset;
% lon_all = lon_all - lon_offset;

%% Find [x, y] Coordinates

x = zeros(length(lat_all), 1);
y = zeros(length(lat_all), 1);
for i = 1:length(lat_all)
    [x(i), y(i)] = latlon_to_xy(lat_all(i), lon_all(i), calibration.node_lat, calibration.node_lon);
    %[x(i), y(i)] = latlon_to_xy(lat_all(i), lon_all(i), lat_n, lon_n);
end


%% Plotting

figure(1);
clf;
hold on;

% plot calibration
plot(calibration.start_x, calibration.start_y, 'linestyle', 'none', 'marker', 'o', 'markersize', 16, 'color', 'r');
text(calibration.start_x, calibration.start_y, 'start');
plot(calibration.stop_x, calibration.stop_y, 'linestyle', 'none', 'marker', '+', 'markersize', 16, 'color', 'r');
text(calibration.stop_x, calibration.stop_y, 'stop');

%plot(x, y, 'linestyle', 'none', 'marker', '.', 'markersize', 20);
plot(x(1), y(1), 'linestyle', 'none', 'marker', 'o', 'markersize', 20);
plot(x(end), y(end), 'linestyle', 'none', 'marker', '+', 'markersize', 20);
scatter(x, y, [], strength);
%scatter(lat_all - lat_n, lon_all - lon_n, [], strength);
colorbar;
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
grid on;
hold off;

%% Animation

x_limits = [min(x), max(x)];
y_limits = [min(y), max(y)];
figure(2);
clf;
hold on;
xlim(x_limits);
ylim(y_limits);
plot(calibration.start_x, calibration.start_y, 'linestyle', 'none', 'marker', 'o', 'markersize', 16, 'color', 'r');
plot(calibration.stop_x, calibration.stop_y, 'linestyle', 'none', 'marker', '+', 'markersize', 16, 'color', 'r');

for i = 1:length(x)
    plot(x(i), y(i), 'linestyle', 'none', 'marker', '.', 'markersize', 16, 'color', 'k');
    pause(0.05);
end
hold off;


%% Scattered Interpolant Bit

F = scatteredInterpolant(x, y, strength');
F.Method = 'natural';
F.ExtrapolationMethod = 'none';

step = 1; % meter
li = 80;
[xx, yy] = meshgrid(-li:step:li, -li:step:li);

figure(3);
%surf(xx, yy, F(xx, yy), 'edgecolor', 'none');
mesh(xx, yy, F(xx, yy));
title('Range and Gain');
xlabel('Meter');
ylabel('Meter');
zlabel('Signal Strength [dBm]');
colorbar;



%% Function to go from Lat/Lon to XY Coordinates (Relative to Node Reference Point)

function [x, y, r, theta, r2] = latlon_to_xy(lat, lon, reflat, reflon)
    R_earth = 6371e3; % radius of earth in meter
    % convert to radians
    lat = lat * pi/180;
    lon = lon * pi/180;
    reflat = reflat * pi/180;
    reflon = reflon * pi/180;

    r = R_earth * acos(sin(lat) * sin(reflat) + cos(lat) * cos(reflat) * cos(lon - reflon));

    x = (lon - reflon) * cos((lat + reflat) / 2);
    y = lat - reflat;
    r2 = R_earth * sqrt(x^2 + y^2);

    theta = atan2(sin(lon-reflon) * cos(lat-reflat), cos(reflat) * sin(lat) - sin(reflat) * cos(lat) * cos(lon - reflon));


    %x = r * cos(theta);
    %y = r * sin(theta);
    x = r * sin(theta); % north is defined as zero degrees!
    y = r * cos(theta); % north is defined as zero degrees!
end


function decimal = ddmmss2decimal(dd, mm, ss)
% convert degrees, minutes, seconds into decimal
    decimal = dd + mm/60 + ss/3600;
end